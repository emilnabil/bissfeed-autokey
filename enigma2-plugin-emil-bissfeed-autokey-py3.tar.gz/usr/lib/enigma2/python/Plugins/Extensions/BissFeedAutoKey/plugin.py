#!/usr/bin/python
# -*- coding: utf-8 -*-
# python3
from __future__ import print_function
# for localized messages
try:
	from . import _
except:
	pass

from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.InfoBar import InfoBar
from Screens.InputBox import InputBox
from ServiceReference import ServiceReference
from Components.Label import Label
from Components.Input import Input
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.NimManager import nimmanager
from Components.Console import Console
from Components.Pixmap import Pixmap
from Components.AVSwitch import AVSwitch
from Components.ConfigList import ConfigListScreen
from Components.config import config, ConfigSubsection, ConfigText, ConfigInteger, ConfigYesNo, getConfigListEntry, ConfigSelection, ConfigIP
from enigma import ePicLoad, ePixmap, getDesktop
from enigma import iServiceInformation, eTimer, iFrontendInformation, eServiceReference, iDVBFrontend, iPlayableServicePtr
from Tools.Directories import fileExists, resolveFilename, SCOPE_PLUGINS,SCOPE_SKIN
from array import array
from time import gmtime, strftime, localtime, strptime
from datetime import datetime, timedelta
from twisted.web.http_headers import Headers
from base64 import b64decode
import os, sys, base64, binascii, time, socket, ftplib, re, json

if sys.version_info[0] == 3:
	from urllib.request import urlopen as compat_urlopen
	from urllib.request import Request as compat_Request
	from urllib.error import URLError as compat_URLError
	from urllib.error import HTTPError as compat_HTTPError
	from http.client import HTTPException
else:
	# Not Python 3 - today, it is most likely to be Python 2
	# But note that this might need an update when Python 4
	# might be around one day
	from urllib2 import urlopen as compat_urlopen
	from urllib2 import Request as compat_Request
	from urllib2 import URLError as compat_URLError
	from urllib2 import HTTPError as compat_HTTPError
	from httplib import HTTPException

try:
	from difflib import SequenceMatcher
except:
	pass

import requests
from requests.auth import HTTPBasicAuth
from requests.auth import HTTPDigestAuth
plugin_dir = resolveFilename(SCOPE_PLUGINS, "Extensions/BissFeedAutoKey")
#==============================================================================================================
def softkeydir():
	keydir = os.popen("find /etc/tuxbox/* /usr/keys /var/keys /etc/keys /var/emu/* /var/etc/* /usr/tuxbox/* /var/tuxbox/* /etc/vdr/* -iname Softcam.key").read()#v1.4
	lkeydir = keydir.splitlines()
	dirchoice = []
	if len(lkeydir) > 1:#v1.5
		dirn = 0
		
		for ii in lkeydir:
			dirn += 1
			g = (ii,ii)
			dirchoice.append(g)#v2

	elif len(lkeydir) == 1:
		dirchoice = [(lkeydir[0],lkeydir[0])]#v2
	else:
		dirchoice = [("/Warning: SoftCam.Key Not Found in STB" ,"/Warning: SoftCam.Key Not Found in STB")]#v2
	return dirchoice
		
dirchoice = softkeydir()
#===================================================================================================================
def readip():#v2
	try:
		f = os.popen("ifconfig").read().splitlines()

		for line in f:
			if "inet" in line and "192" in line:
				ipm = line.split()[1]
				return [(int(ipm.split('.')[0])), (int(ipm.split('.')[1])), 
					(int(ipm.split('.')[2])), (int(ipm.split('.')[3]))]
			else:
				return [(127),(0),(0),(1)]
	except:
		return [(127),(0),(0),(1)]

#===================================================================================================================
def readwebinfo():#V2
	keydir = os.popen("find /etc/tuxbox/* /usr/keys /var/keys  /etc/keys /var/emu/* /var/etc/* /usr/tuxbox/* /var/tuxbox/* /etc/vdr/* -iname *.conf").read()#v2
	#keydir = os.popen("find  /var/keys -iname *.conf").read()#v2
	lkeydir = keydir.splitlines()
	user=''
	passw=''
	try:
		if len(lkeydir) > 0:
			for line in lkeydir:
				f = open(line, 'r')
				ff = open(line, 'r').read()
				d = f.readlines()
				f.seek(0)
				if ff.count("httpport") > 0:
					for iii in d:
						if "httpport" in iii:
							wbifport = int(iii.split('=')[1].strip())
						elif "httpuser" in iii:
							user = iii.split('=')[1].strip()
						elif "httppwd" in iii:
							passw = iii.split('=')[1].strip()

						elif "httpallowed" in iii:
							if "127.0.0.1" in iii:
								wbifip = [127, 0, 0, 1]
							else:
								wbifip = readip()
				else:
					wbifport = 8888
					wbifip = readip()
		else:#V2.1
			wbifport = 8888
			wbifip = readip()

	except:
		wbifport = 8888
		wbifip = readip()

	return (wbifip,wbifport,user,passw)

wbifinfo = readwebinfo() 

#========================================================================================================================
config.plugins.BissFeedAutoKey = ConfigSubsection()
config.plugins.BissFeedAutoKey.keydir = ConfigSelection(default = dirchoice[0][0], choices = dirchoice)
config.plugins.BissFeedAutoKey.deldate = ConfigText(default='date', fixed_size=False)
config.plugins.BissFeedAutoKey.userid = ConfigText(default='userid', fixed_size=False)
config.plugins.BissFeedAutoKey.n = ConfigInteger(default=0, limits=(0, 1))
config.plugins.BissFeedAutoKey.Fullhd = ConfigYesNo(default = True)
config.plugins.BissFeedAutoKey.delkey = ConfigYesNo(default = True)
config.plugins.BissFeedAutoKey.revlnb = ConfigYesNo(default = False)
config.plugins.BissFeedAutoKey.virkeyboard = ConfigYesNo(default = True)
config.plugins.BissFeedAutoKey.port= ConfigInteger(default = wbifinfo[1], limits=(0,65536))
config.plugins.BissFeedAutoKey.ip= ConfigIP(default = wbifinfo[0], auto_jump=True)
config.plugins.BissFeedAutoKey.user = ConfigText(default=wbifinfo[2], fixed_size=False)
config.plugins.BissFeedAutoKey.passw = ConfigText(default=wbifinfo[3], fixed_size=False)
config.plugins.BissFeedAutoKey.reader = ConfigYesNo(default = False)
config.plugins.BissFeedAutoKey.readern = ConfigText(default='SoftCam', fixed_size=False)
Pluginname = _('BissFeedAutoKey')
Author = _('momi133')
version = _('OE2.5 & OE2 -V3.0')
FULLHD = False
if getDesktop(0).size().width() > 1800:
	FULLHD = True

#=================================================================================================================
FULLHD = False
if getDesktop(0).size().width() > 1800:
	FULLHD = True
#===================================================================================================================
class PSetting(ConfigListScreen,Screen):#V2 foregroundColor="#00ff0080"

	skin = """
		<screen position="center,center" size="700,600" title="BissFeedAutoKey(OE2) Ver:3.0">
			<widget name="Label1" position="10,5" size="800,40" font="Regular;28" foregroundColor="#00ff0080" transparent="1"/>
  			<widget name="config" position="center,50" size="680,450" itemHeight="40" scrollbarMode="showOnDemand" transparent="1"/>
			<widget name="ok" position="430,550" size="130,40" valign="center" halign="center" zPosition="1" font="Regular;30" backgroundColor="green" />
			<widget name="cancel" position="150,550" size="130,40" valign="center" halign="center" zPosition="1" font="Regular;30" backgroundColor="red" />

		</screen>"""

	def __init__(self, session, args = 0):
		self.session = session

		Screen.__init__(self, session)
		self["ok"] = Label(_("Save")) #V2
		self["cancel"] = Label(_("Cancel"))#V2
		self["Label1"] = Label(_("Please Set IP:Port to WEBIF Setting(.conf file)"))

		self.list = []
		self.list.append(getConfigListEntry(_("SoftCam.Key:"), config.plugins.BissFeedAutoKey.keydir))
		self.list.append(getConfigListEntry(_("Webif IP:"), config.plugins.BissFeedAutoKey.ip))
		self.list.append(getConfigListEntry(_("Webif Port:"), config.plugins.BissFeedAutoKey.port))
		self.list.append(getConfigListEntry(_("Webif User:"), config.plugins.BissFeedAutoKey.user))
		self.list.append(getConfigListEntry(_("Webif Password:"), config.plugins.BissFeedAutoKey.passw))

		if config.plugins.BissFeedAutoKey.Fullhd.value:
			self.list.append(getConfigListEntry(_("Disable FullHD Skin"), config.plugins.BissFeedAutoKey.Fullhd))
		else:
			self.list.append(getConfigListEntry(_("Enable FullHD Skin"), config.plugins.BissFeedAutoKey.Fullhd))

		if config.plugins.BissFeedAutoKey.delkey.value:
			self.list.append(getConfigListEntry(_("Disable Delete Old Keys"), config.plugins.BissFeedAutoKey.delkey))
		else:
			self.list.append(getConfigListEntry(_("Enable Delete Old Keys"), config.plugins.BissFeedAutoKey.delkey))

		if config.plugins.BissFeedAutoKey.virkeyboard.value:
			self.list.append(getConfigListEntry(_("Disable Virtual Keyboard"), config.plugins.BissFeedAutoKey.virkeyboard))
		else:
			self.list.append(getConfigListEntry(_("Enable Virtual Keyboard"), config.plugins.BissFeedAutoKey.virkeyboard))

		if config.plugins.BissFeedAutoKey.revlnb.value:#v2.8
			self.list.append(getConfigListEntry(_("Disable Reverse LNB"), config.plugins.BissFeedAutoKey.revlnb))
		else:
			self.list.append(getConfigListEntry(_("Enable Reverse LNB"), config.plugins.BissFeedAutoKey.revlnb))

		if config.plugins.BissFeedAutoKey.reader.value:#v2.9
			self.list.append(getConfigListEntry(_("Disable Reset Softcam Reader"), config.plugins.BissFeedAutoKey.reader))
		else:
			self.list.append(getConfigListEntry(_("Enable Reset Softcam Reader"), config.plugins.BissFeedAutoKey.reader))

		self.list.append(getConfigListEntry(_("Insert Reader Name"), config.plugins.BissFeedAutoKey.readern))

		ConfigListScreen.__init__(self, self.list)

		self["myActionMap"] = ActionMap(["SetupActions", "ColorActions"],
		{
			"ok": self.save,
			"green": self.save,#V2
			"cancel": self.cancel,
			"red": self.cancel #V2
		}, -2)

	def save(self):
		config.plugins.BissFeedAutoKey.Fullhd.save()
		config.plugins.BissFeedAutoKey.delkey.save()
		config.plugins.BissFeedAutoKey.virkeyboard.save()
		config.plugins.BissFeedAutoKey.keydir.save()
		config.plugins.BissFeedAutoKey.port.save()
		config.plugins.BissFeedAutoKey.ip.save()
		config.plugins.BissFeedAutoKey.save()

		self.session.open(MessageBox, 'All changes Saved. \nSoftCam.Key:: %s \nIP:PORT :: %s:%s'%(config.plugins.BissFeedAutoKey.keydir.getText(),
		  (config.plugins.BissFeedAutoKey.ip.genText()[0]),str(config.plugins.BissFeedAutoKey.port.value)),MessageBox.TYPE_INFO)

	def cancel(self):
		self.close(None)

#===================================================================================================================
class UpdateFeedKey(Screen):#V2.2 new SNG-AGC BAR  
	skinL = '''
<screen position="center,center" size="1502,950" title="BissFeedAutoKey By momi133" flags="wfNoBorder" backgroundColor="transparent">
	<ePixmap position="center,center" size="1502,950" zPosition="0" transparent="1" alphatest="on"  pixmap="'''+ plugin_dir +'''/BUTTON/BISSLITEfh.png"/>

	<widget source="session.CurrentService" render="Label" position="520,135" size="480,40" font="Regular;28" transparent="1" backgroundColor="#00ff0080" foregroundColor="#00ff0080" halign="center" zPosition="1">
	<convert type="ServiceName">Name</convert>
	</widget>
	<widget source="session.CurrentService" render="Label" position="500,195" size="255,40" font="Regular;26" foregroundColor="#0000f7ff" backgroundColor="#0000f7ff" transparent="1" halign="center" zPosition="1">
	<convert type="BFAServiceName2">Satellite</convert>
	</widget>
	<widget source="session.CurrentService" render="Label" position="750,195" size="255,40" font="Regular;28" backgroundColor="#0000f7ff" foregroundColor="#0000f7ff" transparent="1" halign="center" zPosition="1">
	<convert type="BFAServiceName2">%F %p %Y</convert>
	</widget>
	<widget source="session.CurrentService" render="Label" position="507,260" size="490,40" font="Regular;28" backgroundColor="#00ff0080" foregroundColor="#00ff0080" transparent="1" halign="center" zPosition="1">
	<convert type="BFAServiceInfo2">xAll</convert>
	</widget>
	<widget name="Label1" position="520,323" size="350,40" font="Regular;28" backgroundColor="#0000f7ff" foregroundColor="#0000f7ff" halign="center" transparent="1" zPosition="1"/>
	<widget name="Label2" position="893,325" size="100,40" font="Regular;30" backgroundColor="#0000f7ff" foregroundColor="#0000f7ff" halign="center" transparent="1" zPosition="1"/>
	<widget name="Label3" position="518,390" size="485,40" font="Regular;24" backgroundColor="#00ff0080" foregroundColor="#00ff0080" halign="center" transparent="1" zPosition="1"/>
	<widget name="Label4" position="500,450" size="250,50" font="Regular;30" backgroundColor="#0000f7ff" foregroundColor="#0000f7ff" halign="center" transparent="1" zPosition="1"/>
	<widget name="Label5" position="700,453"  size="350,50" font="Regular;24" backgroundColor="#0000f7ff" foregroundColor="#0000f7ff" halign="center" transparent="1" zPosition="1"/>
	<widget name="Label6" position="543,508" size="500,50" font="Regular;32" backgroundColor="#00ff0080" foregroundColor="#00ff0080" halign="center" transparent="1" zPosition="1"/>

	<widget source="session.FrontendStatus" render="Label" position="115,0" size="200,100" backgroundColor="#0000f7ff" foregroundColor="#0000f7ff" font="Regular;40" halign="center" valign="center" transparent="1" zPosition="1">
	<convert type="FrontendInfo">SNRdB</convert>
	</widget>
	<widget source="session.FrontendStatus" render="Label" position="1200,0" size="200,100" backgroundColor="#00ff0080" foregroundColor="#00ff0080" font="Regular;40" halign="center" valign="center" transparent="1" zPosition="1">
	<convert type="FrontendInfo">AGC</convert>
	</widget>
	<widget source="session.FrontendStatus" render="Progress" orientation="orBottomToTop" position="150,100" size="463,718" transparent="1" alphatest="on" zPosition="1" pixmap="'''+ plugin_dir +'''/BUTTON/sngagcbar.png" >
	<convert type="FrontendInfo">SNR</convert>
	</widget>
	<widget source="session.FrontendStatus" render="Progress" orientation="orBottomToTop" position="1238,102" size="463,718" transparent="1" alphatest="on" zPosition="1" pixmap="'''+ plugin_dir +'''/BUTTON/sngagcbar.png" >
	<convert type="FrontendInfo">AGC</convert>
	</widget>

	<ePixmap position="855,598" size="145,95" alphatest="on" zPosition="1" pixmap="'''+ plugin_dir +'''/LEAGUE/BISS.png"/>

	<widget name="ligpic" position="687,596" size="145,90" zPosition="1" />
	<widget name="satpic" position="517,596" size="145,90" zPosition="1" />
</screen>'''

#==================================================================================
	skinS = '''
<screen position="center,center" size="1001,633" title="BissFeed AutoKey By momi133" flags="wfNoBorder" backgroundColor="transparent">
<ePixmap position="center,center" size="1001,633" zPosition="0" pixmap="'''+ plugin_dir +'''/BUTTON/BISSLITEhd.png"/>
<widget source="session.CurrentService" render="Label" position="345,89" size="320,27" font="Regular;24" backgroundColor="#00ff0080" foregroundColor="#00ff0080" transparent="1" halign="center" zPosition="1">
<convert type="ServiceName">Name</convert>
</widget>
<widget source="session.CurrentService" render="Label" position="345,131" size="175,27" font="Regular;20" transparent="1" foregroundColor="#0000f7ff" backgroundColor="#0000f7ff" halign="left" zPosition="1">
<convert type="BFAServiceName2">Satellite</convert>
</widget>
<widget source="session.CurrentService" render="Label" position="500,131" size="170,27" font="Regular;20" backgroundColor="#0000f7ff" foregroundColor="#0000f7ff" transparent="1" halign="center" zPosition="1">
<convert type="BFAServiceName2">%F  %p  %Y</convert>
</widget>
<widget source="session.CurrentService" render="Label" position="353,173" size="310,27" font="Regular;19" backgroundColor="#00ff0080" foregroundColor="#00ff0080" transparent="1" halign="center" zPosition="1">
<convert type="BFAServiceInfo2">xAll</convert>
</widget>
<widget name="Label1" position="342,215" size="250,25" font="Regular;20" backgroundColor="#0000f7ff" foregroundColor="#0000f7ff" halign="center" transparent="1" zPosition="1"/>
<widget name="Label2" position="593,215" size="80,25" font="Regular;20" backgroundColor="#0000f7ff" foregroundColor="#0000f7ff" halign="center" transparent="1" zPosition="1"/>
<widget name="Label3" position="345,258" size="325,25" font="Regular;20" backgroundColor="#00ff0080" foregroundColor="#00ff0080" halign="center" transparent="1" zPosition="1"/>
<widget name="Label4" position="347,300" size="150,25" font="Regular;20" backgroundColor="#0000f7ff" foregroundColor="#0000f7ff" halign="center" transparent="1" zPosition="1"/>
<widget name="Label5" position="500,300"  size="200,25" font="Regular;20" backgroundColor="#0000f7ff" foregroundColor="#0000f7ff" halign="center" transparent="1" zPosition="1"/>
<widget name="Label6" position="392,339" size="270,27" font="Regular;23" backgroundColor="#00ff0080" foregroundColor="#00ff0080" halign="center" transparent="1" zPosition="1"/>
<widget source="session.FrontendStatus" render="Label" position="75,0" size="140,40" backgroundColor="#0000f7ff" foregroundColor="#0000f7ff" font="Regular;34" halign="center" transparent="1" zPosition="1">
<convert type="FrontendInfo">SNRdB</convert>
</widget>
<widget source="session.FrontendStatus" render="Label" position="790,0" size="150,40" backgroundColor="#00ff0080" foregroundColor="#00ff0080" font="Regular;34" halign="center" transparent="1" zPosition="1">
<convert type="FrontendInfo">AGC</convert>
</widget>
<widget source="session.FrontendStatus" render="Progress" orientation="orBottomToTop" position="100,64" size="79,348" transparent="1" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BissFeedAutoKey/BUTTON/sngagcbarS.png" >
      <convert type="FrontendInfo">SNR</convert>
    </widget>
<widget source="session.FrontendStatus" render="Progress" orientation="orBottomToTop" position="825,65" size="79,348" transparent="1" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BissFeedAutoKey/BUTTON/sngagcbarS.png" >
      <convert type="FrontendInfo">AGC</convert>
    </widget>

<ePixmap position="569,396" size="100,66" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BissFeedAutoKey/LEAGUE/BISSsd.png"/>

<widget name="ligpic" position="456,396" size="100,66" zPosition="1" transparent="1"/>
<widget name="satpic" position="343,396" size="100,66" zPosition="1" transparent="1"/>

</screen>'''
#SOLVE THIS ERROR 70 11020 V =>error @570 11019 V: USE +70 11020 V IN DATABASE AND SEARCH +70 BY REP FUNCTION

	def __init__(self, session):
		l1 = 'udXhgfHJKQtc3VwcG'
		self.addkey = False
		self.bisscaid = False
		self.session = session
		if config.plugins.BissFeedAutoKey.Fullhd.value:		
			if FULLHD:#V2
				self.skin = self.skinL
			else:
				self.skin = self.skinS
		else:
				self.skin = self.skinS
		Screen.__init__(self, session)
		self.mytext = 'NO CW FOUND :('
		satpic1 = 'picon_default'		
		self.ckey = "" # constant.cw format
		self.skey = "" # SoftCam.Key format
		self.freq = 0
		self.dlerr = 0
		self.words = ["aHR0cHM6Ly45d3cubGl",
			'CW NOT FOUND :(','-',
			'NO FEED INFO :(','-',
			'NO COMMENT INFO :(','-','-',
			'LWVwdfgd56r763vZmV']

		self.Console = Console()
		service2 = self.session.nav.getCurrentlyPlayingServiceReference()
		l3= "lZGJpc3MudHh0"
		if service2 is not None:
			self.chname = ServiceReference(service2).getServiceName()
		
		service = self.session.nav.getCurrentService()
		isnotStream = True
		if isinstance(service, iPlayableServicePtr):#V2.5
			info = service and service.info()
			refstr = info.getInfoString(iServiceInformation.sServiceref)
			if '%3a//' in refstr or refstr.startswith("4097:"):
				isnotStream = False

		ttype = None
		self.dvbstun = (nimmanager.hasNimType("DVB-S") or nimmanager.hasNimType("DVB-S2"))
		if service is not None and self.dvbstun and isnotStream:
			self.words[0]="'aHR0cHM6Ly93d3cubGl"
			infofreq = service.frontendInfo()
			freqData = infofreq.getAll(True)
			ttype = freqData.get("tuner_type")

		if ttype == "DVB-S" or ttype == "DVB-S2":
			freq = freqData.get('frequency', 0) // 1000
			self.freq = freq
			l3= "4eFYudHh0'"
			freqq = range (freq - 4 , freq + 5)
			l2='GRSZGNVclp4V0RzYS9HVFh6'
			l1 = 'BsdWdpbi5keC5hbS9pbWFnZXMvS'
			satpos = freqData['orbital_position']
			ll3='aHR0cDovL2UycGx1Z2lu'
			if satpos > 1800:
				satpos1 = satpos - 3600
			else:
				satpos1 = satpos
			ll4='cy5pci9IZFJkY1VyWnhXRHNhL'
			satposs = range(satpos1-4,satpos1+5)#V2
			satname = str(nimmanager.getSatName(satpos))
			satangg = satname.split(' ')
			self.words[8]='U3dRNWQzajk'
			self.satang = satangg[0]
			satpic1 = self.satang.replace('.','')
			mm4 = '0dUWHpTd1E1ZDNqOTh4Vi50eHQ='
			self.srate = freqData.get('symbol_rate', 0) / 1000
			self.words[0]="'aHR0cDovL3d3dy5iaXNzZm"
			poln = freqData['polarization']
			self.words[0]="'aHR0cDovL2Jpc3NmZWVka2V5c3"
			if config.plugins.BissFeedAutoKey.revlnb.value:
				if poln == 1:
					pol = 'H' 
				else:
					pol = 'V' 
			else:
				if poln == 0:
					pol = 'H' 
				else:
					pol = 'V' 

			self.pol = pol

			f3 ='1111'
			f3 = self.updata2(b64decode(self.words[0]+l1+l2+self.words[8]+l3))

			if self.dlerr == 1 or f3.count('= @#@#') < 5 or f3.count('LifeTime') < 5:#V2.8 
				f3 = self.updata2(b64decode(ll3+ll4+mm4))
				#f3 = self.updata2(b64decode(self.words[0]+l1+l2+self.words[8]+l3))

			rep = self.repfind(f3,satposs,freqq,pol)# V2
			#myfeed = filter(lambda x: x.count(rep)==1, f3.splitlines()) #V2
			myfeed = [x for x in f3.splitlines() if x.count(rep)==1]
			if len(myfeed) == 1:
				if myfeed[0].split('=')[1].strip()!='':
					self.words = myfeed[0].split('=')
					self.ckey = self.words[1].strip()
					self.skey = self.ckey.replace(' ', '')
					self['Label6'] = Label(_(self.ckey))
					self.mytext = self.ckey
					

			elif len(myfeed) > 1:
				idsim = []#V2
				#myfeedid = filter(lambda x: x.count(rep)==1 and x.count(self.chname.upper())==1, f3.upper().splitlines())#V2.2 f3.upper()
				myfeedid = [x for x in f3.upper().splitlines() if (x.count(rep)==1 and x.count(self.chname.upper())==1)]
				if len(myfeedid) == 1:
					self.words = myfeedid[0].split('=')
					self.ckey = self.words[1].strip()
					self.skey = self.ckey.replace(' ', '')
					self['Label6'] = Label(_(self.ckey))
					self.mytext = self.ckey


				elif len(myfeedid) == 0:
					try:#V2.5
						for line in myfeed:#V2
							idsim.append(SequenceMatcher(None, line.split('=')[2].upper(), self.chname.upper()).ratio())
						idmax = max(idsim)
						idmaxin = idsim.index(idmax)
						self.words = myfeed[idmaxin].split('=')
						self.ckey = self.words[1].strip()
						self.skey = self.ckey.replace(' ', '')
						self['Label6'] = Label(_(self.ckey))
						self.mytext = self.ckey
					except:#V2.5
						pass
						

		ligpicon = 'picon_default'
		if len(self.words) >= 9:
			ligpicon = self.words[8].strip()


		self['Label1'] = Label(_(self.words[3]))
		self['Label2'] = Label(_(self.words[4].strip()))
		self['Label3'] = Label(_(self.words[5].strip()))
		self['Label4'] = Label(_(self.words[6].strip()))
		self['Label5'] = Label(_(self.words[7].strip()))#ttype
		self['Label6'] = Label(_(self.mytext))
		self['satpic'] = Pixmap()
		self['ligpic'] = Pixmap()
		self['myActionsMap'] = ActionMap(['SetupActions', 'ColorActions'], {'ok': self.oscamMsg,
			'green': self.oscamMsg,
			'blue': self.plconf,
			'yellow': self.plconf,
			'red': self.cancel,
			'cancel': self.cancel}, -1)

		self.Scale = AVSwitch().getFramebufferScale()
		self.PicLoad = ePicLoad()

		self.Scale2 = AVSwitch().getFramebufferScale()
		self.PicLoad2 = ePicLoad()

		if fileExists(resolveFilename(SCOPE_SKIN,'piconSat/%s.png' % satpic1)):#V2.6
			self.picPath2 = resolveFilename(SCOPE_SKIN,'piconSat/%s.png' % satpic1)

		elif fileExists('/media/usb/piconSat/%s.png' % satpic1):#V2.6
			self.picPath2 = '/media/usb/piconSat/%s.png' % satpic1

		else:
			self.picPath2 = resolveFilename(SCOPE_PLUGINS,'Extensions/BissFeedAutoKey/LEAGUE/picon_default.png')
			
		if fileExists(resolveFilename(SCOPE_PLUGINS,'Extensions/BissFeedAutoKey/LEAGUE/white/%s.png' % ligpicon)):#V2.5
			self.picPath = resolveFilename(SCOPE_PLUGINS,'Extensions/BissFeedAutoKey/LEAGUE/white/%s.png' % ligpicon)
		else:
			self.picPath = resolveFilename(SCOPE_PLUGINS,'Extensions/BissFeedAutoKey/LEAGUE/white/picon_default.png')

		try: ## Edit By RAEd To DreamOS
			self.PicLoad.PictureData.get().append(self.DecodePicture)
			self.PicLoad2.PictureData.get().append(self.DecodePicture2)
		except:
			self.PicLoad_conn = self.PicLoad2.PictureData.connect(self.DecodePicture)
			self.PicLoad2_conn = self.PicLoad2.PictureData.connect(self.DecodePicture2)
		
		self.onLayoutFinish.append(self.ShowPicture)
		self.onLayoutFinish.append(self.ShowPicture2)
		self.onShown.append(self.setMytText)

	def setMytText(self):
		self['Label6'].setText(self.mytext)

	def ShowPicture(self):
		if self.picPath is not None:
			self.PicLoad.setPara([self['ligpic'].instance.size().width(),
				self['ligpic'].instance.size().height(),
				self.Scale[0],
				self.Scale[1],
				0,
				1,
				'#002C2C39'])
			self.PicLoad.startDecode(self.picPath)

	def ShowPicture2(self):
		if self.picPath2 is not None:
			
			self.PicLoad2.setPara([self['satpic'].instance.size().width(),
				self['satpic'].instance.size().height(),
				self.Scale2[0],
				self.Scale2[1],
				0,
				1,
				'#002C2C39'])

			self.PicLoad2.startDecode(self.picPath2)

	def DecodePicture(self, PicInfo = ''):
		if self.picPath is not None:
			ptr = self.PicLoad.getData()
			self['ligpic'].instance.setPixmap(ptr)

	def DecodePicture2(self, PicInfo = ''):
		if self.picPath2 is not None:
			ptr = self.PicLoad2.getData()
			self['satpic'].instance.setPixmap(ptr)

	#=============================================================================================================
	def plconf(self):
		self.session.open(PSetting)

	#===========================================================================================================
	def repfind(self, f3,list1,list2,pp):#V2
		for ii in range(len(list1)):
			for jj in range(len(list2)):
				rep = str(list1[ii]) + ' ' + str(list2[jj]) + ' ' + pp # 70 11020 V =>error @570 11019 V
				if rep in f3:
					return rep
				
		return '000 momi133 000'
	#===========================================================================================================
	def updata(self,url):#V2.1
		headers1 = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Firefox/66.0.3 Chrome/51.0.2704.103 Safari/537.36',
		       'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		       'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
		       'Accept-Encoding': 'none',
		       'Accept-Language': 'en-US,en;q=0.8',
		       'Connection': 'keep-alive'} #V2 By audi06_19 #V2.1 'User-Agent' edited By myself
		headers2 = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Firefox/66.0.3 Chrome/78.0.3904.70 Safari/537.36',
		   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 
		   'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3', 
		   'Accept-Encoding': 'none', 
		   'Accept-Language': 'tr,en-US;q=0.9,en;q=0.8', 
		   'Connection': 'keep-alive'}

		timeout = 5
		socket.setdefaulttimeout(timeout)
		request = compat_Request(url, None, headers1)#V2 By audi06_19
		resp = ''
		try:
			resp = compat_urlopen(request)
		except compat_HTTPError as e:
			self.mytext = 'Host Error'
			self.dlerr = 1
			f3 = ''
		except compat_URLError as e:
			self.mytext = 'Internet Conection ERR!'
			self.dlerr = 1
			f3 = ''
		except socket.error as e:
			self.mytext = 'Socket Conection ERR!'
			self.dlerr = 1
			f3 = ''
		except socket.timeout as e:
			self.dlerr = 1
			self.mytext = 'Socket Conection ERR!'
			f3 = ''
		else:
			self.mytext = 'NO CW FOUND :('
			self.dlerr = 0
			f3 = ''.join(resp.readlines()).decode("utf-8-sig").encode("utf-8")

		return f3

	def updata2(self,url):
		headers1 = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Firefox/66.0.3 Chrome/51.0.2704.103 Safari/537.36',
		       'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		       'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
		       'Accept-Encoding': 'none',
		       'Accept-Language': 'en-US,en;q=0.8',
		       'Connection': 'keep-alive'} 


		try:
			#response=requests.get(url, verify=False, headers=headers1, auth=HTTPBasicAuth(hex(uuid.getnode()).replace('L',''),hex(uuid.getnode()).replace('L','')))
			response=requests.get(url, verify=False)#,headers = headers1)
			response.raise_for_status()
			resp = response.content

		except requests.exceptions.HTTPError as errh:
			#if errh.response.status_code == 401:
			self.mytext = ' moom133@gmail.com'
			self.dlerr = 1
			f3 = ''
			#if response.status_code == 200:

		except requests.exceptions.ConnectionError as errc:
			self.mytext = 'Internet Conection ERR!'
			#self.mytext = str(errc.response.status_code)+': Internet Conection ERR!'
			self.dlerr = 1
			f3 = ''

		except requests.exceptions.Timeout as errt:
			self.mytext = 'Timeout Error'
			self.dlerr = 1
			f3 = ''

		except requests.exceptions.RequestException as err:
			self.mytext = 'Unknown Error'
			self.dlerr = 1
			f3 = ''

		else:
			self.mytext = 'NO CW FOUND :('
			self.dlerr = 0
			if sys.version_info[0] == 3:
				f3 = resp.decode("utf-8-sig")
			else:
				f3 = ''.join(resp).decode("utf-8-sig").encode("utf-8")
		return f3

	#=================================================================================================================
	def ResSoftcam(self):
		if config.plugins.BissFeedAutoKey.reader.value:
			url = 'http://%s:%s/readers.html?action=reread&label=%s'%(str(config.plugins.BissFeedAutoKey.ip.genText()[0]),str(config.plugins.BissFeedAutoKey.port.value),config.plugins.BissFeedAutoKey.readern.value)
		else:
			url = 'http://%s:%s/shutdown.html?action=Restart'%(str(config.plugins.BissFeedAutoKey.ip.genText()[0]),str(config.plugins.BissFeedAutoKey.port.value))
		try:
			resp = compat_urlopen(url)
		except compat_HTTPError as e:
			if e.code == 401:
				self.session.open(MessageBox, _("SoftCam.Key Updated. Please Restart SoftCam.\n\nFor AutoRestarting Please Remove USER:PASS in Webif>>>Config file"), MessageBox.TYPE_INFO)
			else:
				self.session.open(MessageBox, _("SoftCam.Key Updated. Please Restart SoftCam.\n\nFor AutoRestarting SoftCam, Add '127.0.0.1' in Webif>>>httpallowed in Config file"), MessageBox.TYPE_INFO)
		except compat_URLError as e:
			self.session.open(MessageBox, _("SoftCam.Key Updated. Please Restart SoftCam.\n\nFor AutoRestarting SoftCam, Change Webif>>>httpport To %s in Config file"%(str(config.plugins.BissFeedAutoKey.port.value))), MessageBox.TYPE_INFO)
		else:
			if config.plugins.BissFeedAutoKey.reader.value:
				self.session.open(MessageBox, _('SoftCam.Key Updated & Reader is Restarting ...!'), MessageBox.TYPE_INFO, timeout=8)
			else:
				self.session.open(MessageBox, _('SoftCam.Key Updated & SoftCam is Restarting ...!'), MessageBox.TYPE_INFO, timeout=8)
	#=================================================================================================================
	def Resreader(self):
		if config.plugins.BissFeedAutoKey.reader.value:
			url = 'http://%s:%s/readers.html?action=reread&label=%s'%(str(config.plugins.BissFeedAutoKey.ip.genText()[0]),str(config.plugins.BissFeedAutoKey.port.value),config.plugins.BissFeedAutoKey.readern.value)
		else:
			url = 'http://%s:%s/shutdown.html?action=Restart'%(str(config.plugins.BissFeedAutoKey.ip.genText()[0]),str(config.plugins.BissFeedAutoKey.port.value))

		try:
			response = requests.get(url,timeout=5)
			response.raise_for_status()
		except requests.exceptions.HTTPError as errh:
			if errh.response.status_code == 401:    
				#from requests.auth import HTTPBasicAuth
				try:
					response=requests.get(url,  verify=False,auth=HTTPBasicAuth(config.plugins.BissFeedAutoKey.user.value, config.plugins.BissFeedAutoKey.passw.value))
				except:
					pass
			if response.status_code == 401:    
				#from requests.auth import HTTPDigestAuth
				try:
					response=requests.get(url,  verify=False,auth=HTTPDigestAuth(config.plugins.BissFeedAutoKey.user.value,config.plugins.BissFeedAutoKey.passw.value))
				except:
					pass

			if response.status_code == 401:
				self.session.open(MessageBox, _("[User/Pass Error] SoftCam.Key Updated. Please Restart SoftCam.\n\nFor AutoRestarting Please Edit OR Remove USER:PASS in Webif>>>Config file"), MessageBox.TYPE_INFO, timeout=10)

			if response.status_code == 200:
				if config.plugins.BissFeedAutoKey.reader.value:
					self.session.open(MessageBox, _('[User/Pass] SoftCam.Key Updated & Reader is Restarting ...!'), MessageBox.TYPE_INFO, timeout=8)
				else:
					self.session.open(MessageBox, _('[User/Pass] SoftCam.Key Updated & SoftCam is Restarting ...!'), MessageBox.TYPE_INFO, timeout=8)

		except requests.exceptions.ConnectionError as errc:
			self.session.open(MessageBox, _("SoftCam.Key Updated. Please Restart SoftCam.\n\nFor AutoRestarting SoftCam, Please check Webif IP/PORT in Webif>>>Config file and Plugin Setting"), MessageBox.TYPE_INFO)

		except requests.exceptions.Timeout as errt:
			self.session.open(MessageBox, _("[Timeout Error] SoftCam.Key Updated. Please Restart SoftCam Manually."), MessageBox.TYPE_INFO, timeout=8)
		
		except requests.exceptions.RequestException as err:
			self.session.open(MessageBox, _("[unkown Error] SoftCam.Key Updated. Please Restart SoftCam Manually."), MessageBox.TYPE_INFO, timeout=8)
		else:
			if config.plugins.BissFeedAutoKey.reader.value:
				self.session.open(MessageBox, _('[NO User/Pass] SoftCam.Key Updated & Reader is Restarting ...!'), MessageBox.TYPE_INFO, timeout=8)
			else:
				self.session.open(MessageBox, _('[NO User/Pass] SoftCam.Key Updated & SoftCam is Restarting ...!'), MessageBox.TYPE_INFO, timeout=8)


	#===========================================================================================================
	def upaddkey(self):#V2 By audi06_19 Help
		
		isaddkey = fileExists(resolveFilename(SCOPE_PLUGINS,"Extensions/AddKey/plugin.py")) or \
			fileExists(resolveFilename(SCOPE_PLUGINS,"Extensions/AddKey/plugin.pyo"))
		iskeyadder = fileExists(resolveFilename(SCOPE_PLUGINS,"Extensions/KeyAdder/plugin.py")) or \
			fileExists(resolveFilename(SCOPE_PLUGINS,"Extensions/KeyAdder/plugin.pyo"))
		#if result:
		#try :
		if isaddkey and config.plugins.BissFeedAutoKey.virkeyboard.value:
			from Plugins.Extensions.AddKey.plugin import AddKeyUpdate
			self.session.open(AddKeyUpdate)
			self.addkey = True
		elif iskeyadder and config.plugins.BissFeedAutoKey.virkeyboard.value:
			try :
				from Plugins.Extensions.KeyAdder.plugin import AddKeyUpdate
				self.session.open(AddKeyUpdate)
				self.addkey = True
			except:
				from Plugins.Extensions.KeyAdder.plugin import KeyAdderUpdate #V2.8
				self.session.open(KeyAdderUpdate)
				self.addkey = True

		else:
		#self.session.open(MessageBox,"Addkey Plugin Not found!",MessageBox.TYPE_ERROR)
			self.session.openWithCallback(self.askForCW, InputBox, title=_('Addkey Plugin Not found!Please Enter BISS Key!'), 
				windowTitle=Pluginname, text='0000000000000000', maxSize=16, type=Input.TEXT)
		#else:
			#self.close(None)

	#=============================================================================================================
	def myInput(self,result):
		
		if result:
			if config.plugins.BissFeedAutoKey.virkeyboard.value:
				self.session.openWithCallback(self.askForCW, HexKeyBoard,
					title=_("Please Enter New Key:"), text='')

			else:
				self.session.openWithCallback(self.askForCW, InputBox, title=_('Please Enter BISS Key!'), 
					windowTitle=Pluginname, text='0000000000000000', maxSize=16, type=Input.TEXT)

		else:
			self.close(None)
	#=================================================================================================================
	def isaddkeyinsert(self):#2.1
		try:#V2.1
			aa = strftime('%Y-%m-%d', localtime()) #Added on 2019-10-08 01:03:19.736605 in addkey plugin
			if sys.version_info[0] == 3:
				f = open(config.plugins.BissFeedAutoKey.keydir.getText(), 'r', encoding="utf-8",errors='ignore')
			else: 
				f = open(config.plugins.BissFeedAutoKey.keydir.getText(), 'r')
			d = f.readlines()
			if d[-1].count("Added on")>0 and d[-1].count(self.chname)>0 and d[-1].count(aa)>0 and d[-1].count(self.satang)>0:#self.satang and modifiredtime < 1 minute:
				return True
		except:
			return False

		return False


	#===============================================================================================================
	def askForCW(self, feedcw):

		if feedcw is None:
			pass
		else:
			keyinput = feedcw.upper() #feedcw='ab345678123456cd'
			biskey = ' '.join(keyinput[i:i + 2] for i in range(0, len(keyinput), 2))
			ref = self.session.nav.getCurrentlyPlayingServiceReference()
			sidd = ref.getUnsignedData(1)
			tsidd = ref.getUnsignedData(2)
			onidd = ref.getUnsignedData(3)
			ens = ref.getUnsignedData(4)
			if ens & 0xFFFF == 0:
				data = "%04X%04X%04X%08X" % (sidd, tsidd, onidd, ens | 0xA0000000)
			else:
				data = "%04X%08X" % (sidd, ens | 0xA0000000)
			nmspace = crc32(binascii.unhexlify(data))

			a = strftime("%d-%m-%Y %H:%M:%S", localtime())
			camkey = "F %0.8X 00000000 %s" % (nmspace, keyinput)

			import string
			if not fileExists(config.plugins.BissFeedAutoKey.keydir.getText()):
				self.session.open(MessageBox, 'SoftCam.Key File Not Found!\n Please Set Directory in Setting(BlueKey)',MessageBox.TYPE_ERROR)

			elif len(keyinput.strip()) != 16 or not all(c in string.hexdigits for c in keyinput):
				self.session.open(MessageBox, biskey + ' is Wrong BISS Key. \n BISS Key must be in 16 hexdigits', MessageBox.TYPE_ERROR)

			else:
				self.mytext = biskey
				self.setMytText()
				f = open(config.plugins.BissFeedAutoKey.keydir.getText(), 'a')
				f.write('\n%s ; %s @ %s %s-%s-%s By BissFeedAutoKey @ %s' % (camkey,
					self.chname,self.satang,self.freq,self.pol,self.srate,a))
				f.close()
				self.Resreader()
		return
	#==============================================================================================================
	def oscamMsg(self):
		a = strftime('%d-%m-%Y %H:%M:%S', localtime())
		c = 'BissFeedAutoKey'
		self.Console.ePopen('chmod 777 %s' % config.plugins.BissFeedAutoKey.keydir.getText())

		if config.plugins.BissFeedAutoKey.n.value == 0 and config.plugins.BissFeedAutoKey.delkey:#V2
			config.plugins.BissFeedAutoKey.n.value = 1
			config.plugins.BissFeedAutoKey.deldate.value = a
			config.plugins.BissFeedAutoKey.save()
			if fileExists(config.plugins.BissFeedAutoKey.keydir.getText()):
				try:#V2
					if sys.version_info[0] == 3:
						f = open(config.plugins.BissFeedAutoKey.keydir.getText(), 'r+', encoding='utf-8', errors='ignore')
					else:
						f = open(config.plugins.BissFeedAutoKey.keydir.getText(), 'r+')
					d = f.readlines()
					f.seek(0)
					for iii in d:
						if c in iii and 'LifeTime' not in iii:
							keinfo = iii.split(' ')
							tt = keinfo[-1].strip() 
							td = keinfo[-2].strip()
							ttdelta = datetime.strptime(a, '%d-%m-%Y %H:%M:%S') - datetime.strptime(td + ' ' + tt, '%d-%m-%Y %H:%M:%S')
							if ttdelta > timedelta(hours=12):
								continue
						elif not iii.strip():
							continue
						f.write(iii)

					f.truncate()
					f.close()
				except:
					pass
			else:
				self.session.open(MessageBox, 'SoftCam.Key File Not Found!\n Please Set Directory in Setting(BlueKey)', MessageBox.TYPE_ERROR)

		elif config.plugins.BissFeedAutoKey.n.value == 1:
			ttdelta = datetime.strptime(a, '%d-%m-%Y %H:%M:%S') - datetime.strptime(config.plugins.BissFeedAutoKey.deldate.value, '%d-%m-%Y %H:%M:%S')
			if ttdelta > timedelta(hours=12):
				config.plugins.BissFeedAutoKey.n.value = 0
				config.plugins.BissFeedAutoKey.save()

		service = self.session.nav.getCurrentService()
		try:
			infofreq2 = service.frontendInfo()
			lockst = infofreq2.getFrontendInfo(iFrontendInformation.lockState)
		except:
			lockst = 0
			
		allcaids = service and service.info()
		if allcaids is not None:
			caids = allcaids.getInfoObject(iServiceInformation.sCAIDs)
			if caids:
				for caid in caids:
					if ('%0.4X' % int(caid))[:2] == '26':
						self.bisscaid = True

		if self.ckey != '' and lockst == 1 and self.dvbstun and self.bisscaid:
			cam1 = 'ZjI0LXByZXZpZXcu'
			#======================================
			ref = self.session.nav.getCurrentlyPlayingServiceReference()
			sidd = ref.getUnsignedData(1)
			tsidd = ref.getUnsignedData(2)
			onidd = ref.getUnsignedData(3)
			ens = ref.getUnsignedData(4)
			if ens & 0xFFFF == 0:
		    		data = "%04X%04X%04X%08X" % (sidd, tsidd, onidd, ens | 0xA0000000)
			else:
		    		data = "%04X%08X" % (sidd, ens | 0xA0000000)
			nmspace = crc32(binascii.unhexlify(data))
			mac2 = 'aDViQ2c4RHkwRlpTWEBNb21JMTMz'
			#========================================

			if fileExists(config.plugins.BissFeedAutoKey.keydir.getText()):
				if sys.version_info[0] == 3:
					f1 = open(config.plugins.BissFeedAutoKey.keydir.getText(), encoding='utf-8', errors='ignore').read()
				else:
					f1 = open(config.plugins.BissFeedAutoKey.keydir.getText()).read()
				camkey = 'F %0.8X 00000000 %s' % (nmspace, self.skey)
				camkey2 = 'F %0.8X 00 %s' % (nmspace, self.skey)

				if camkey not in f1 and camkey2 not in f1:
					if sys.version_info[0] == 3:
						f = open(config.plugins.BissFeedAutoKey.keydir.getText(), mode = 'a', encoding="utf-8", errors='ignore')
					else:
						f = open(config.plugins.BissFeedAutoKey.keydir.getText(), 'a')

					if self.words[7].strip() != 'LifeTime' and self.words[6].strip() != 'LifeTime':
						f.write('\n%s ; %s @ %s %s-%s-%s By BissFeedAutoKey @ %s' % (camkey,
							self.chname,self.satang,self.freq,self.pol,self.srate,a))
					else:
						f.write('\n%s ; %s @ %s %s-%s-%s By BissFeedAutoKey @ %s ::LifeTime Key' % (camkey,
							self.chname,self.satang,self.freq,self.pol,self.srate,a))
					f.close()
					self.Resreader()
					#self.ResSoftcam() 

				else:
					self.upaddkey()#self.session.openWithCallback(self.upaddkey, MessageBox,
						#_("Key Found in SoftCam.Key... \nDo you want to Add New BISS key?"), MessageBox.TYPE_YESNO)

			else:
				self.session.open(MessageBox, 'SoftCam.Key File Not Found!\n Please Set Directory in Setting(BlueKey)', MessageBox.TYPE_ERROR)

		elif self.ckey == '' and self.bisscaid and lockst == 1:#self.myInput
			self.upaddkey()
		elif self.ckey == '' and  self.dlerr == 1:
			self.session.open(MessageBox, 'Error! Please Check Internet Conection.', MessageBox.TYPE_ERROR, timeout=5)

		elif not self.dvbstun:
			self.session.open(MessageBox, 'No Satellite tuner is configured.!!!', MessageBox.TYPE_ERROR, timeout=5)

		elif lockst == 0:
			self.session.open(MessageBox, 'No Signal :(', MessageBox.TYPE_ERROR, timeout=5)

		elif not self.bisscaid:
			self.session.open(MessageBox, 'Not BISS Encrypted!!!', MessageBox.TYPE_ERROR, timeout=5)
	#=======================================================================================================================
	def cancel(self):
		service2 = self.session.nav.getCurrentlyPlayingServiceReference()
		service = self.session.nav.getCurrentService()
		if service2 and service:
			allpidsinfo = service.info()
			vsize = allpidsinfo.getInfo(iServiceInformation.sVideoHeight)
			if self.bisscaid and self.addkey and self.isaddkeyinsert():
				#self.ResSoftcam()
				self.Resreader()
				#self.session.nav.stopService()
				#self.session.nav.playService(service2)

			#elif self.bisscaid and (not fileExists("/tmp/ecm.info") or os.stat("/tmp/ecm.info").st_size == 0 or vsize<100):
				#self.session.nav.stopService()
				#self.session.nav.playService(service2)

		self.close(False, self.session)
###########################################################################
def crc32(stringg):

	table = array('L')

	for byte in range(256):
		crc = 0
		for bit in range(8):
			if (byte ^ crc) & 1:
				crc = (crc >> 1) ^ 0xEDB88320
			else:
				crc >>= 1
			byte >>= 1
		table.append(crc)

	value = 0x2600 ^ 0XFFFFFFFF
	for char in stringg:
		if sys.version_info[0] == 3:
			value = table[((char) ^ value) & 0XFF] ^ (value >> 8)
		else:
			value = table[(ord(char) ^ value) & 0XFF] ^ (value >> 8)

	return value ^ 0XFFFFFFFF
#########################################################################
def FeedAutoKey(session, **kwargs):
	session.open(UpdateFeedKey)
###########################################################################
def Plugins(**kwargs):
	return PluginDescriptor(name=Pluginname, description='Auto update of BissFeed Key(OE2)', where=[PluginDescriptor.WHERE_PLUGINMENU,PluginDescriptor.WHERE_EXTENSIONSMENU], icon='BissFeedAutoKey.png', fnc=FeedAutoKey)

